temp_F = input('Vnesi temperaturo v °F: ')
temp_C = (temp_F - 32) / 1.8
print(temp_F, '°F je', temp_C, '°C.')