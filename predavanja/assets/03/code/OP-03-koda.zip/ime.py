ime = input('Povej svoje ime: ')
if ime:
    print('Živjo,', ime + '!')
else:
    print('Pojdi se solit!')
