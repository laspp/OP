"""Naš lasten modul

Uporabimo v igri ugibanja števil.
"""

start = 20
stop  = 30
maks_poskusov = 5
bes_uvod = (
    'Izbral sem si število med ' +
    str(start) + ' in ' + str(stop) +
    '.'
    )
bes_poziv = 'Ajde, ugibaj, katero: '
bes_poziv_spet = 'Poskusi ponovno: '
bes_napacno = 'Ah, kje pa, nimaš pojma.'
bes_konec_poskusov = 'Zmanjkalo ti je poskusov :('
bes_bravo = 'Bravo! Bereš mi misli.'
bes_resitev = 'Izbral sem število'
bes_cas = 'Čas igranja: ??? sekund.'

