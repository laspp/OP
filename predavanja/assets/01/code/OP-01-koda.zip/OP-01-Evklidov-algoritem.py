A = 100
B = 75
while A != B:
    if A > B:
        A = A - B
    else:
        B = B - A
print(A)