"""Zanka for: primer z nizom"""

for znak in 'ju.pi':
    if znak == '.':
        break
    print(znak)
else:
    print('dupi')
print('hej')