temp_F = 30
temp_C = (temp_F - 32) / 1.8
print(temp_C)
